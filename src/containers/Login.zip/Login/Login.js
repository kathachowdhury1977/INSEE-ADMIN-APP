import React, { useState } from 'react';
import {useHistory} from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { useTranslation, withTranslation } from 'react-i18next';
import Button from '../../components/Button/Button'
import './Login.scss';


const Login = () => {
	const { t } = useTranslation()
	let history = useHistory();
	const [convertedText, setConvertedText] = useState('en');

	function handleChange(event, name) {
		console.log(event, "event target", name)

	}
	const handleSubmit = () => {
		history.push("/UserManagment");
		// const user = {
		// 	name: 'Jorge García',
		// 	token: Math.random().toString(36).substring(7)
		// };

		// localStorage.setItem('session', JSON.stringify(user));
		// dispatch({
		// 	type: 'SET_SESSION',
		// 	payload: user
		// });
	
	};

	return (
		<Grid className="LoginContainer">
			<div  className="container login_sec">
			<div className="row">
			
				<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div className="login_img">
				   <div className="login_right_sec">
						<div className="title-heading">
							<h4 className="head_txt">
				
								Log In
							</h4>
							<Typography  className="sub_head">
						
								This is a sucure system and you will need to provide your login details to access the site
							</Typography>
						</div>
						<div className="Login_Section form_section">
							<form onSubmit={() => handleSubmit()}>
							      <div className="inputBox ">
                                           <input type={"email"} name={"email"} onChange={handleChange} placeholder="Email" className="input"/>
                                        </div>

										<div className="inputBox ">
                                           <input type={"password"} name={"password"} onChange={handleChange} placeholder="Password" className="input"/>
                                        </div>
	
							     	<Button type={"submit"} label="Login" />
							</form>
						   </div>				
						 </div>
						</div>


				   </div>
		    	</div>

			</div>
			
		</Grid>
	);
}

export default withTranslation()(Login);
